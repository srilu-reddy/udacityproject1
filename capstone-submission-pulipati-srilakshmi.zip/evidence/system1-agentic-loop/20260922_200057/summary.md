# Run summary — 20260922_200057

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1250** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 3 | 0 | 9380 | 512 | 0.0119 | 18.0 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6051 | 384 | 0.008 | 5.2 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 6214 | 467 | 0.0085 | 5.6 |
| claim_04_neighbor_injury | routed | liability | high | 6 | 0 | 21401 | 1009 | 0.0264 | 14.8 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 15185 | 973 | 0.0201 | 10.7 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 6284 | 602 | 0.0093 | 9.2 |
| claim_07_tree_falls_on_car | routed | auto | high | 5 | 0 | 18405 | 986 | 0.0233 | 15.9 |
| claim_08_minor_porch_damage | incomplete | - | - | 4 | 0 | 13327 | 820 | 0.0174 | 11.6 |
